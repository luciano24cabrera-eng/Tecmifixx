# SO_Reportes_Fallas
Repositorio para el trabajo grupal de Sistemas Operativos ENE-MAY-2026
